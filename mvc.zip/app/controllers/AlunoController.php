<?php

namespace app\controllers;
//pra executar este código preciso deste arquivo
use app\core\Controller;

class AlunoController extends Controller{

    public function index(){
        echo "Agora sim";
    }

    public function listar(){
        echo "Lista de alunos";
    }

    public function salvar($nome,$turma=null,$horario=null){
        echo "O valor passado foi {$nome} ";
        if($turma){
            echo "e a turma {$turma}";
        }
        if($horario){
            echo "Horário: {$horario}";
        }
    }
}